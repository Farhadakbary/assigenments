import 'package:test/test.dart';

void main() {
  test('calculate', () {

  });
}
